#망고픽

## 파일 리스트
- app/src/main/java/com/study/restaurant/fragment/[MangoPickFragment.java](/app/src/main/java/com/study/restaurant/fragment/MangoPickFragment.java)
- app/src/main/java/com/study/restaurant/fragment/[StoryFragment.java](/app/src/main/java/com/study/restaurant/fragment/StoryFragment.java)
- app/src/main/java/com/study/restaurant/fragment/[TopListFragment.java](/app/src/main/java/com/study/restaurant/fragment/TopListFragment.java)


## API
[http://sarang628.iptime.org:83/php/getStory.php](http://sarang628.iptime.org:83/php/getStory.php)