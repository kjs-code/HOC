# [설계] 스토리 보드 만들기
https://docs.google.com/presentation/d/1lnIcCSdxju_wRRwW0msWjdMBYY1iroJgfuuHko581SE/edit?usp=sharing