# [설계]E-R 다이어그램 만들기
https://docs.google.com/presentation/d/1AXUKGqAz0R7g7W-9_Ngv-A-xTmkTb9DsmH8RsGpq9Hc/edit?usp=sharing