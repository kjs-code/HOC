# [분석] 개발 진행 순서

안드로이드 API 백오피스에 대한 개발 순서를 정리하였다.

https://docs.google.com/spreadsheets/d/1nKL-JR1eK7Tm3izWX5QHTUr6P29f5PsEHh305RujalA/edit?usp=sharing