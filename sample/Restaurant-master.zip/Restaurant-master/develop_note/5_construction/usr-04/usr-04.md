# 백오피스 회원 상세정보 개발



<img src = 0.png width = 1000px>

운영자 및 관리자만 볼 수 있는 페이지, 회원 리스트를 관리하는 상세페이지이다.

user_detail.php
```
<div style="margin-left: 20px">

    <div style="width: 150px; height: 150px; overflow: hidden; margin: 10px; position: relative;">
        <img src="<?php echo $row['profile_pic_url'] ?>" width="150px" height="150px"
             style="border-radius: 50%;">
    </div>

    <table class="customers" style="width: 500px; table-layout: fixed;">
        <tr>
            <th width="100px">No</th>
            <th width="100px">ID</th>
            <th width="100px">이름</th>
            <th width="100px">등급</th>
        </tr>
        <tr>
            <td><?php echo $row['user_id'] ?></td>
            <td><?php echo $row['email'] ?></td>
            <td><input id="name" value="<?php echo $row['name'] ?>"></td>
            <?php
            $level = $row['level'];
            if ($level == 1) {
                echo "<td>
                      운영자
                      </td>";
            } else {
                echo sprintf("<td>
                <select id='level'>
                    <option %s>관리자</option>
                    <option %s>에디터</option>
                    <option %s>서포터즈</option>
                    <option %s>일반사용자</option>
                    <option %s>차단사용자</option>
                </select>
            </td>", $level == 2 ? "selected" : ""
                    , $level == 3 ? "selected" : ""
                    , $level == 4 ? "selected" : ""
                    , $level == 5 ? "selected" : ""
                    , $level == 6 ? "selected" : "");
            }
            ?>
        </tr>
    </table>

    <table class="customers" style="width: 500px; table-layout: fixed;">
        <tr>
            <th width="100px">로그인 플렛폼</th>
        </tr>
        <tr>
            <td><?php echo $row['login_platform'] ?></td>
        </tr>
        <tr>
            <th width="100px">프로필 이미지</th>
        </tr>
        <tr>
            <td><input id="profile_pic_url" value="<?php echo $row['profile_pic_url'] ?>"></td>
        </tr>
    </table>

    <table class="customers" style="width: 500px; table-layout: fixed;">
        <tr>
            <th width="100px">팔로워</th>
            <th width="100px">팔로잉</th>
            <th width="100px">리뷰</th>
            <th width="100px">체크인</th>
            <th width="100px">사진</th>
        </tr>
        <tr>
            <td><?php echo $row['follower'] ?></td>
            <td><?php echo $row['following'] ?></td>
            <td><?php echo $row['review'] ?></td>
            <td><?php echo $row['checkin'] ?></td>
            <td><?php echo $row['upload_pictures'] ?></td>
        </tr>
    </table>

    <div style="height: 120px; position: relative; min-height: 120px; margin-top: 20px">
        <div>
            <button onclick="mod()" style="background: #1D809F; color: white; border: 0px; font-size: 20px">수정하기
            </button>
            <button onclick="del()" style="background: #1D809F; color: white; border: 0px; font-size: 20px">삭제하기
            </button>
        </div>
    </div>

    <form id="mod_form" action="controller/ctr_mod_user.php" type="hidden" method="post"/>
    <form id="del_form" action="controller/ctr_delete_user.php" type="hidden" method="post"/>
</div>
```

수정 함수 구현 부
```
function mod() {
        if (confirm("수정하시겠습니까?")) {
            var uid = "<?php echo $user_id?>";
            var form1 = document.getElementById("mod_form");
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "user_id");
            hiddenField.setAttribute("value", uid);
            form1.appendChild(hiddenField);
            //이름
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "name");
            hiddenField.setAttribute("value", document.getElementById("name").value);
            form1.appendChild(hiddenField);
            //사용자 사진
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "profile_pic_url");
            hiddenField.setAttribute("value", document.getElementById("profile_pic_url").value);
            form1.appendChild(hiddenField);
            //사용자 등급
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "level");
            hiddenField.setAttribute("value", document.getElementById("level").selectedIndex+2);
            form1.appendChild(hiddenField);
            form1.submit();
        }
    }
```