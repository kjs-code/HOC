# 에디터, 서포터즈, 블랙리스트 등록하기


<img src = 0.png width = 1000px>


user_detail.php
```
<?php
$level = $row['level'];
if ($level == 1) {
    echo "<td>
      운영자
      </td>";
} else {
    echo sprintf("<td>
<select id='level'>
    <option %s>관리자</option>
    <option %s>에디터</option>
    <option %s>서포터즈</option>
    <option %s>일반사용자</option>
    <option %s>차단사용자</option>
</select>
</td>", $level == 2 ? "selected" : ""
        , $level == 3 ? "selected" : ""
        , $level == 4 ? "selected" : ""
        , $level == 5 ? "selected" : ""
        , $level == 6 ? "selected" : "");
}
?>

```

수정 함수 구현 부
```
function mod() {
            ...
            //사용자 등급
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "level");
            hiddenField.setAttribute("value", document.getElementById("level").selectedIndex + 2);
            form1.appendChild(hiddenField);
            form1.submit();
            ...
        }
    }
```