# 운영자 회원리스트에 대한 수정, 등록, 삭제 기능 개발

회원리스트의 수정, 삭제 기능은 회원 상세정보에서 할 수 있으며, 등록은 등록페이지가 따로 구현되어있다.

사용자 등록화면
<img src = 0.png width = 1000px>
사용자 상세화면
<img src = 1.png width = 1000px>

register_user.php
```
<div style="margin-left: 20px">
    <div style="width: 150px; height: 150px; overflow: hidden; margin: 10px; position: relative;">
        <img src="<?php echo $row['profile_pic_url'] ?>" width="150px" height="150px"
             style="border-radius: 50%;">
    </div>

    <form action="javascript:mod()">
        <table class="customers" style="width: 500px; table-layout: fixed;">
            <tr>
                <th width="100px">No</th>
                <th width="100px">ID</th>
                <th width="100px">이름</th>
                <th width="100px">등급</th>
            </tr>
            <tr>
                <td><?php echo $row['user_id'] ?></td>
                <td>
                    <input id="email" value="<?php echo $row['email'] ?>" required="required">
                </td>
                <td><input id="name" value="<?php echo $row['name'] ?>" required="required"></td>
                <?php
                $level = $row['level'];
                if ($level == 1) {
                    echo "<td>
                      운영자
                      </td>";
                } else {
                    echo sprintf("<td>
                <select id='level'>
                    <option %s>관리자</option>
                    <option %s>에디터</option>
                    <option %s>서포터즈</option>
                    <option %s>일반사용자</option>
                    <option %s>차단사용자</option>
                </select>
            </td>", $level == 2 ? "selected" : ""
                        , $level == 3 ? "selected" : ""
                        , $level == 4 ? "selected" : ""
                        , $level == 5 ? "selected" : ""
                        , $level == 6 ? "selected" : "");
                }
                ?>
            </tr>
        </table>

        <table class="customers" style="width: 500px; table-layout: fixed;">
            <tr>
                <th width="100px">로그인 플렛폼</th>
                <th width="100px">비밀번호</th>
            </tr>
            <tr>
                <td><?php echo $row['login_platform'] ?></td>
                <td><input id="password" placeholder="password" required="required"></td>
            </tr>
            <tr>
                <th width="100px" colspan="2">프로필 이미지</th>
            </tr>
            <tr>
                <td colspan="2"><input id="profile_pic_url" value="<?php echo $row['profile_pic_url'] ?>"></td>
            </tr>
        </table>

        <table class="customers" style="width: 500px; table-layout: fixed;">
            <tr>
                <th width="100px">팔로워</th>
                <th width="100px">팔로잉</th>
                <th width="100px">리뷰</th>
                <th width="100px">체크인</th>
                <th width="100px">사진</th>
            </tr>
            <tr>
                <td><?php echo $row['follower'] ?></td>
                <td><?php echo $row['following'] ?></td>
                <td><?php echo $row['review'] ?></td>
                <td><?php echo $row['checkin'] ?></td>
                <td><?php echo $row['upload_pictures'] ?></td>
            </tr>
        </table>

        <div style="height: 120px; position: relative; min-height: 120px; margin-top: 20px">
            <div>
                <input type="submit" value="등록하기"
                       style="background: #1D809F; color: white; border: 0px; font-size: 20px">
                </input>
            </div>
        </div>
    </form>

    <form id="mod_form" action="controller/ctr_reg_user.php" type="hidden" method="post"/>
</div>
```

수정 함수 구현 부
```
function mod() {
        if (confirm("등하시겠습니까?")) {
            var uid = "<?php echo $user_id?>";
            var form1 = document.getElementById("mod_form");
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "user_id");
            hiddenField.setAttribute("value", uid);
            form1.appendChild(hiddenField);
            //이름
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "name");
            hiddenField.setAttribute("value", document.getElementById("name").value);
            form1.appendChild(hiddenField);
            //사용자 사진
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "profile_pic_url");
            hiddenField.setAttribute("value", document.getElementById("profile_pic_url").value);
            form1.appendChild(hiddenField);
            //비밀번호
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "password");
            hiddenField.setAttribute("value", document.getElementById("password").value);
            form1.appendChild(hiddenField);
            //이메일
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "email");
            hiddenField.setAttribute("value", document.getElementById("email").value);
            form1.appendChild(hiddenField);
            //사용자 등급
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "level");
            hiddenField.setAttribute("value", document.getElementById("level").selectedIndex + 2);
            form1.appendChild(hiddenField);
            form1.submit();
        }
    }
```