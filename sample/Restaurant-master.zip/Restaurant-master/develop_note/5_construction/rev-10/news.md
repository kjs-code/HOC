# 소식 개발하기

[TOC]

## 기능 정리

- 소식은 사용자가 남긴 리뷰의 리스트이다.
- 사용자는 하나의 식당에 하나의 리뷰를 남길 수 있다.
- 리뷰에서의 점수는 식당의 평점에 기준이 된다.
- 리뷰를 작성할 때 여러장의 사진을 올릴 수 있다.
- 리뷰에서 업로드한 사진은 맛집 상세화면의 소개사진리스트가 된다.
- 리뷰에서 업로드한 사진은 맛집 앨범의 형식으로 제공된다.
- 사용자는 자신이 남긴 리뷰 리스트를 볼 수 있어야한다.
- 사용자는 리뷰에서올린 사진들을 앨범 형식으로 볼 수 있어야한다.
- 소식은 전체, 내가 팔로잉한 사람들, 홀릭 세가지 형태로 제공되야한다.
- 리뷰에는 댓글을 남길 수 있다.
- 리뷰를 즐겨찾기와 좋아요를 할 수 있다.
- 리뷰리스트에 내용은 사용자명, 사용자의 리뷰갯수, 팔로워수, 평점, 식당명, 리뷰내용 5줄 내외, 업로드한 사진 5개 내외, 즐겨찾기, 좋아요, 댓글, 신고로 구성된다.



## 소식 ERD

<img src = ./erd.png width=600px > 



## 소식 데이터  논리 설계

사진에 리뷰아이디가 있어야 사용자가 업로드한 리뷰에 사진들을 불러올수가 있었다ㅠㅠ

<img src = ./logic.png width=700px >





https://github.com/sarang628/Restaurant/blob/master/develop_note/5_construction/news/news.md




## 소식 API 개발하기

### url

{baseUrl}/getNews.php

### 쿼리

```
SELECT Review .* , User.name, User.profile_pic_url, User.follower, User.review,  Picture.pic_url
FROM Review 
LEFT OUTER JOIN Picture ON Review.review_id = Picture.review_id
JOIN `User` ON Review.user_id = User.user_id
ORDER BY Review.create_date DESC
```

### 재가공
리뷰에 해당하는 사진데이터가 리스트로 제공되어야 하는데 쿼리로는 3차원 배열을 만드는 방법을 모르겠어서 코드로 수작업을 해주었다.

```
for ($i = 0; $i < sizeof($json); $i++) {
            $contain = false;
            //echo print_r($json[$i]);
            for ($j = 0; $j < sizeof($newArray); $j++) {
                if ($newArray[$j]['review_id'] == $json[$i]['review_id']) {
                    $contain = true;
                    $position1 = sizeof($newArray[$j]['storePictures']);
                    $newArray[$j]['storePictures'][$position1]['pic_id'] = $json[$i]['pic_id'];
                    $newArray[$j]['storePictures'][$position1]['number'] = $json[$i]['number'];
                    $newArray[$j]['storePictures'][$position1]['pic_url'] = $json[$i]['pic_url'];
                    $newArray[$j]['storePictures'][$position1]['date'] = $json[$i]['date'];
                    break;
                }

            }
            //
            if ($contain == false) {
                $position = sizeof($newArray);
                $newArray[$position] = $json[$i];
                $newArray[$position]['storePictures'][0]['pic_id'] = $json[$i]['pic_id'];
                $newArray[$position]['storePictures'][0]['number'] = $json[$i]['number'];
                $newArray[$position]['storePictures'][0]['pic_url'] = $json[$i]['pic_url'];
                $newArray[$position]['storePictures'][0]['date'] = $json[$i]['date'];
            }
        }
```



### API 요청 결과값

```
[
    {
        "review_id": "59",
        "user_id": "1",
        "store_id": "88",
        "score": "5",
        "contents": "스시가 땡긴다",
        "like_count": null,
        "comment_count": null,
        "create_date": "2019-05-20 17:17:04",
        "name": "양사랑",
        "profile_pic_url": "http://k.kakaocdn.net/dn/baSSVJ/btqmthM6cBp/ikqEwepJiqwQK4GyV09d3k/profile_640x640s.jpg",
        "follower": "0",
        "review": "0",
        "pic_url": "1/2019-05-20/17:17:04.260911.jpg",
        "storePictures": [
            {
                "pic_id": null,
                "number": null,
                "pic_url": "1/2019-05-20/17:17:04.260911.jpg",
                "date": null
            },
            {
                "pic_id": null,
                "number": null,
                "pic_url": "1/2019-05-20/17:17:04.263264.jpg",
                "date": null
            },
            {
                "pic_id": null,
                "number": null,
                "pic_url": "1/2019-05-20/17:17:04.261964.jpg",
                "date": null
            }
        ]
    }
    ...
```

## 소식 안드로이드 개발
### 망고플레이트 화면
<img src = ./ui.jpg width=500px >
### 개발 화면
<img src = ./screen.jpg width=500px >

### 프레그먼트명
NewsListFragment

### 소식 리스트 요청하기

```
void requestNews() {
    //뉴스 피드 요청하기
    Map<String, String> param = new HashMap<>();
    ApiManager.getInstance().getNews(param, new ApiManager.CallbackListener() {
        @Override
        public void callback(String result) {
            Type type = new TypeToken<ArrayList<News>>() {
            }.getType();
            ArrayList<News> newsArrayList = new Gson().fromJson(result, type);
            ((ReviewRvAdt) rvNewsList.getAdapter()).setNewsList(newsArrayList);
            srlNewsList.setRefreshing(false);
        }

        @Override
        public void failed(String msg) {
            Toast.makeText(getContext(), "소식 요청에 실패하였습니다.", Toast.LENGTH_SHORT).show();
        }
    });
}
```