## 맛집 상세화면

### 맛집 상세화면에 필요한 데이터 정리

```
1. 맛집 소개 이미지 5장
2. 맛집 이름
3. 맛집 조회수, 즐겨찾기 수, 리뷰 수
4. 맛집 주소
5. 편의정보
 - 영업시간
 - 가격
 - 음식종류
 - 웹사이트
 - 등록한 유저
6. 리뷰 최대 3개
7. 탑리스트 최대 4개
8. 주변 인기 식당 최대 4개
9. 관련 스토리 최대 4개
```

### 서버에서 주는 데이터를 그대로 모델로 사용하면 안된다

Json으로 파싱하기 귀찮다면 Gson을 사용하되 반드시 해당 API주는 데이터를 ResponseBody모델을 따로 만든 후 안드로이드용도에 맞게 변경이 필요하다. 서버에서는  데이터를 일차원으로 주던 다차원으로 주던 서버는 화면에 필요한 데이터만 정확하게 전달해주면된다. 서버에서 가끔 같은 데이터도 파라미터명을 다르게 주는 경우가 있기때문에 데이터를 자신이 이해할 수 있게 변경하도록 하자.

### 사진 상세화면

맛집 상세화면을 진입하면 맛집에 대한 사진 리스트가 나오는데, 이 사진은 사용자가 작성한 리뷰의 업로드한 사진을 기반으로 한다. 그래서 사진을 클릭하면 상세화면으로 진입하며, 사용자가 작성한 리뷰를 볼 수 있게 만들어져있다. 이를 구현하기 위해서 맛집 상세화면에 진입했을때, API에서 주는 이미지에 대한 필요한 데이터를 정리하였다. 정리하다보니 스토어 상세 사진에 대한 데이터는 리뷰를 기반으로 해야한다는것을 알게되었다.

```
스토어 상세 이미지 데이터
리뷰데이터
- 리뷰 아이디
- 맛집 아이디
- 맛집명
- 사용자 프로필 이미지
- 사용자 이름
- 사용자 리뷰 갯수
- 사용자 팔로워 수
- 리뷰 내용
- 등록일
- 사용자 아이디
- 이미지 리스트
```

### 맛집 상세보기 개발하기

이 앱에서 가장 많으 정보가 표시되어야 하는 부분이 아닌가 싶다.

기획서 정리한부분을 보자

[맛집 상세 기획서](https://docs.google.com/presentation/d/1lnIcCSdxju_wRRwW0msWjdMBYY1iroJgfuuHko581SE/edit#slide=id.g45c1f014ad_0_467)

기획서에 나와있는 기능을 정리해보자.
```
1. 닫기 기능
2. 마이리스트 추가
3. 카카오톡 공유
4. 일반 공유
5. 이미지 리스트 
6. 맛집 정보 제공
7. 즐겨찾기
8. 체크인
9. 리뷰쓰기
10. 사진올리기
11. 주소표시
12. 위치 지도로 표시하기
13. 길찾기
14. 네비게이션
15. 택시부르기
16. 주소 복사
17. 전화하기
18. 편의정보
19. 편의정보 더보기
20. 메뉴
21. 메뉴 더보기
22. 잘못된 정보 수정 요청 이동
23. 식당 키워드
24. 베너
25. 맛깔나는 리뷰 필터링 버튼
26. 리뷰 리스트
27. 리뷰 더보기
28. 블로그 검색 기능
29. 관련 TOP리스트 표시
30. 주변 인기 식당 리스트 표시
```

먼저 위에 있는 기능을 빈 함수와 연결시켜 정리해보았다.

```java
/**********************************************************************************************
* function
**********************************************************************************************/

private Store getStore() {
return getIntent().getParcelableExtra("store");
}

/** TODO:: 닫기 기능 */
public void clickClose(View view) {
onBackPressed();
}

/** TODO:: 마이리스트 추가 */
public void addMyList(View v){}

/** TODO:: 카카오톡 공유 */
public void shareKakao(View v){}

/** TODO:: 일반공유 */
public void normarShare(View v){}

/**TODO:: 정보 제공 기능
* 서버에서 받은 정보를 가지고 표시해야하는 기능들
* 이미지 리스트
* 맛집 정보 제공
* 주소표시
* 위치 지도로 표시하기
* 편의정보 표시하기
* 메뉴 표시하기
* 식당 키워드
* 베너
* 리뷰리스트
* 관련 TOP리스트 표시
* 주변 인기 식당 리스트 표시
* */

/** TODO:: 즐겨찾기 */
public void addFavorite(View v){}

/** TODO:: 체크인 */
public void checkIn(View v){}

/** TODO:: 리뷰쓰기 */
public void writeReview(View v){}

/** TODO:: 사진 올리기 */
public void uploadPicture(View v){}

/** TODO:: 길찾기 */
public void findRounte(View v){}

/** TODO:: 네비게이션 */
public void navigation(View v){}

/** TODO:: 택시부르기 */
public void callTaxi(View v){}

/** TODO:: 주소 복사 */
public void copyAddress(View v){}

/** TODO:: 전화하기 */
public void call(View v){}

/** TODO:: 편의정보 더보기 */
public void moreConvenience(View v){}

/** TODO:: 메뉴 더보기 */
public void moreMenu(View v){}

/** TODO:: 잘못된 정보 수정 요청 이동 */
public void requestModify(View v){}

/** TODO:: 맛깔나는 리뷰 필더링 버튼*/
public void reviewFilter(View v){}

/** TODO:: 리뷰 더보기 */
public void moreReview(View v){}

/** TODO:: 블로그 검색 기능 */
public void searchBlog(View v){}
```

그다음엔 레이아웃에서 클릭하는 부분을 연결해보자



위에서 부터 차근차근 개발해보자.

하지만 처음부터 어렵다.

맛집의 이미지를 최대 5장 가져오는 기능인데. 이 사진은 사용자가 리뷰로 올린 이미지를 기반으로 한다.

기존에 리뷰테이블과 이미지 테이블을 분리해놔서 이미지 테이블에서 날짜 순으로 이미지 데이터를 불러오면된다.

스토어의 상세 정보를 가져오는 쿼리를 짜봤다.

```
// 맛집 정보 가져오기
$q = "SELECT * FROM Store WHERE store_id = $store_id"

// 이미지 가져오기
$q = "SELECT * FROM Image WHERE store_id = $store_id";

```