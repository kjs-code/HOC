# 백오피스 맛집 수정하기


수정버튼
```
<button onclick="mod(<?php echo sprintf("'%s', '%s', '%s', '%s'"
                , "1"
                , $store_id
                , $restaurant->holiday
                , $restaurant->price
            ) ?>)"
    style="background: #1D809F; color: white; border: 0px; font-size: 20px">수정하기
</button>
```

수정함수
```
/**
 * TODO:: 맛집 수정 함수
 */
function mod(uid, store_id, holiday, price) {
    if (confirm("맛집을 수정하시겠습니까?!!!")) {
        var form = document.getElementById("mod_form");
        if (form == null) {
            alert("mod_form is null");
        }
        // 식당 아이디
        var hiddenField = document.createElement("input");
        if (store_id != "") {
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "store_id");
            hiddenField.setAttribute("value", store_id);
            form.appendChild(hiddenField);
        }
        alert(document.getElementById("store_name").value);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "store_name");
        hiddenField.setAttribute("value", document.getElementById("store_name").value);
        form.appendChild(hiddenField);
        // TODO:: 맛집 이름
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "introduce");
        hiddenField.setAttribute("value", document.getElementById("introduce").value);
        form.appendChild(hiddenField);
        // //사용자 사진
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "address");
        hiddenField.setAttribute("value", document.getElementById("address").value);
        form.appendChild(hiddenField);
        // //이메일
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "tel");
        hiddenField.setAttribute("value", document.getElementById("tel").value);
        form.appendChild(hiddenField);
        // //이메일
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "parking_information");
        hiddenField.setAttribute("value", document.getElementById("parking_information").value);
        form.appendChild(hiddenField);
        // 오픈시간
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "open_hour");
        hiddenField.setAttribute("value", document.getElementById("open_hour").value);
        form.appendChild(hiddenField);
        // 종료시간
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "close_hour");
        hiddenField.setAttribute("value", document.getElementById("open_hour").value);
        form.appendChild(hiddenField);
        // //이메일
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "last_order");
        hiddenField.setAttribute("value", document.getElementById("last_order").value);
        form.appendChild(hiddenField);
        // //이메일
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "conv_update_date");
        hiddenField.setAttribute("value", document.getElementById("conv_update_date").value);
        form.appendChild(hiddenField);
        //도시 아이디
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "city_id");
        hiddenField.setAttribute("value", document.getElementById("city_id").value);
        form.appendChild(hiddenField);
        //지역 아이디
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "region_id");
        hiddenField.setAttribute("value", document.getElementById("region_id").value);
        form.appendChild(hiddenField);
        // 위도
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "lat");
        hiddenField.setAttribute("value", document.getElementById("lat").value);
        form.appendChild(hiddenField);
        // 경도
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "lon");
        hiddenField.setAttribute("value", document.getElementById("lon").value);
        form.appendChild(hiddenField);
        // 음식 카테고리
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "food_category_id");
        hiddenField.setAttribute("value", document.getElementById("food_category_id").value);
        form.appendChild(hiddenField);
        // 쉬는날
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "holiday");
        hiddenField.setAttribute("value", holiday);
        form.appendChild(hiddenField);
        // 가격
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "price");
        hiddenField.setAttribute("value", price);
        form.appendChild(hiddenField);

        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "imgCount");
        hiddenField.setAttribute("value", imgCount);
        form.appendChild(hiddenField);

        for (var i = 0; i < imgCount; i++) {
            hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "url" + i);
            hiddenField.setAttribute("value", document.getElementById("url" + i).value);
            form.appendChild(hiddenField);
        }

        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "mon_start_hour");
        hiddenField.setAttribute("value", document.getElementById("mon_start_hour").value);
        form.appendChild(hiddenField);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "mon_close_hour");
        hiddenField.setAttribute("value", document.getElementById("mon_close_hour").value);
        form.appendChild(hiddenField);
        //
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "tue_start_hour");
        hiddenField.setAttribute("value", document.getElementById("tue_start_hour").value);
        form.appendChild(hiddenField);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "tue_close_hour");
        hiddenField.setAttribute("value", document.getElementById("tue_close_hour").value);
        form.appendChild(hiddenField);
        //
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "wed_start_hour");
        hiddenField.setAttribute("value", document.getElementById("wed_start_hour").value);
        form.appendChild(hiddenField);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "wed_close_hour");
        hiddenField.setAttribute("value", document.getElementById("wed_close_hour").value);
        form.appendChild(hiddenField);
        //
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "thu_start_hour");
        hiddenField.setAttribute("value", document.getElementById("thu_start_hour").value);
        form.appendChild(hiddenField);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "thu_close_hour");
        hiddenField.setAttribute("value", document.getElementById("thu_close_hour").value);
        form.appendChild(hiddenField);
        //
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "fri_start_hour");
        hiddenField.setAttribute("value", document.getElementById("fri_start_hour").value);
        form.appendChild(hiddenField);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "fri_close_hour");
        hiddenField.setAttribute("value", document.getElementById("fri_close_hour").value);
        form.appendChild(hiddenField);
        //
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "sat_start_hour");
        hiddenField.setAttribute("value", document.getElementById("sat_start_hour").value);
        form.appendChild(hiddenField);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "sat_close_hour");
        hiddenField.setAttribute("value", document.getElementById("sat_close_hour").value);
        form.appendChild(hiddenField);
        //
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "sun_start_hour");
        hiddenField.setAttribute("value", document.getElementById("sun_start_hour").value);
        form.appendChild(hiddenField);
        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "sun_close_hour");
        hiddenField.setAttribute("value", document.getElementById("sun_close_hour").value);
        form.appendChild(hiddenField);

        hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "menu_count");
        hiddenField.setAttribute("value", menuCount);
        form.appendChild(hiddenField);

        for (var i = 0; i < menuCount; i++) {
            hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "menu_url" + i);
            hiddenField.setAttribute("value", document.getElementById("menu_url" + i).value);
            form.appendChild(hiddenField);
            hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "menu_price" + i);
            hiddenField.setAttribute("value", document.getElementById("menu_price" + i).value);
            form.appendChild(hiddenField);
            hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "menu_name" + i);
            hiddenField.setAttribute("value", document.getElementById("menu_name" + i).value);
            form.appendChild(hiddenField);
        }

        form.submit();
    }
}
```

수정 컨트롤러
```
<?php

include '../model/Restaurant.php';
include_once '../common/config.php';
include_once '../model/BusinessHour.php';
include_once '../model/Menu.php';

$mysqli = new mysqli($DB['host'], $DB['id'], $DB['pw'], $DB['db']);
if (mysqli_connect_error()) {
    exit('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}


extract($_POST);
$restaurant = new RestaurantBO();
$restaurant->loadPostData();
$businessHour = new BusinessHourBO();
$businessHour->loadPostData();
$businessHour->store_id = $restaurant->store_id;

$q = $restaurant->updateQuery();
if ($q == null)
    return;
$result = $mysqli->query($q);

//영업시간 수정하기
if ($result == 1) {
    $q = new BusinessHourBO();
    $q = $businessHour->insertQuery();
    $result = $mysqli->query($q);
}

if ($result == 1 && $_POST['menu_count'] > 0) {
    $menu = Array();
    $menuCount = $_POST['menu_count'];
    for ($i = 0; $i < $menuCount; $i++) {
        $menu[$i] = new MenuBO();
        $menu[$i]->loadPostData($i);
        $menu[$i]->store_id = $restaurant->store_id;
    }
    $q = MenuBO::insertQuert($menu);
    $result = $mysqli->query($q);
}

//if ($result == 1 && $restaurant->imgCount > 0) {
//    $q = $restaurant->insertPicture($restaurant->store_id);
//    $result = $mysqli->query($q);
//}


if ($result == 1) {
    echo "<script>alert(\"수정되었습니다.\")</script>";
    echo "<script>window.close();</script>";
} else {
    echo "<br>";
    echo $q;
    echo "<br>";
    echo "수정 실패";
}
    
```
