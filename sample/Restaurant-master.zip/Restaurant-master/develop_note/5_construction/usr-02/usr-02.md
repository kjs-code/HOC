# 운영자 백오피스 로그인



<img src = 0.png width = 800px>



운영자가 로그인 할 수 있는 백오피스 로그인 화면을 만들려고 한다. 운영자 뿐만아니라
관리자, 에디터도 이페이지를 통해서 로그인을 할 수 있다.

login.html
```
<!DOCTYPE html>
<html lang="en">
<body>
<div style="width: 40vw; margin: 0 auto;">
    <center>
        <div style="margin-top: 5vw; margin-bottom: 5vw">
            <h4>바나나 플레이트 백오피스</h4>
        </div>
    </center>
    <form action="controller/login_check.php" method="post">
        <!--이메일-->
        <input id="inputEmail" name="email" class="form-control"
               style="height: 40px"
               placeholder="Email address" required="required" autofocus="autofocus">

        <!--비밀번호-->
        <input type="password" id="inputPassword" name="password" class="form-control"
               style="height: 40px; margin-top: 10px"
               placeholder="Password" required="required">


        <!--기억하기-->
        <div class="checkbox" style="margin-top: 5px">
            <label>
                <input type="checkbox" value="remember-me">
                Remember Password
            </label>
        </div>

        <!--로그인 버튼-->
        <div style="margin-top: 10px;">
            <input type="submit" class="btn btn-primary btn-block" value="login"
                   style="height: 45px;">
        </div>

    </form>
</div>


<!--<div class="text-center">-->
<!--<a class="d-block small mt-3" href="register.html">Register an Account</a>-->
<!--<a class="d-block small" href="forgot-password.html">Forgot Password?</a>-->
<!--</div>-->
</body>

</html>

```

input 테그에 name을 설정하면 post로 해당 값을 넘길 수 있다.
login_check.php 에서 로그인 및 세션할당 기능을 구현하였다.