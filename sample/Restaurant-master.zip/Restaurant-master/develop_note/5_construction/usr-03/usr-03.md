# 백오피스 회원 리스트 개발



<img src = 0.png width = 1000px>

운영자 및 관리자만 볼 수 있는 페이지, 회원 리스트를 관리하는 페이지이다.

user_table.php
```
<!DOCTYPE html>
<html lang="en">

<body id="page-top">

<?php include './common/db_connect.php';
$q = "SELECT * FROM User";
$result = $mysqli->query($q);
?>

<style>
    #customers {
        font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    #customers td, #customers th {
        border: 1px solid #ddd;
        padding: 8px;
    }

    #customers tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    #customers tr:hover {
        background-color: #ddd;
    }

    .pagination {
        display: inline-block;
    }

    .pagination a {
        color: black;
        float: left;
        padding: 8px 16px;
        text-decoration: none;
    }

    .pagination a.active {
        background-color: #4CAF50;
        color: white;
    }

    .pagination a:hover:not(.active) {
        background-color: #ddd;
    }
</style>


<div style="margin-left: 5%; margin-bottom: 20px"><h4>회원관리</h4></div>
<center>
    <table class="table" style="width: 90%; margin-bottom: 10px">
        <tr>
            <td>
                <div style="width: 100%">
                    <div>
                        <input type="checkbox">
                    </div>
                    <div style="float:right;">
                        <input type="search">
                        <input type="submit" value="검색">
                    </div>
                </div>
            </td>
        </tr>
    </table>
</center>
<!--유저 테이블-->
<center>
    <table table id="customers" style="width: 90%; margin-bottom: 20px">
        <thead>
        <th></th>
        <th>이름</th>
        <th>이메일</th>
        <th>로그인</th>
        <th>프로필</th>
        </thead>
        <?php for ($i = 0; $i < $result->num_rows; $i++) {
            $row = $result->fetch_array(MYSQLI_ASSOC); ?>
            <tr>
                <td><input type="checkbox"></td>
                <form action="user_detail.php?user_id=<?php echo $row['user_id'] ?>"
                      method="post" target="_blank">
                    <input type="hidden" style="" name="user_id" value="<?php echo $row['user_id'] ?>">
                    <td><input type="submit" value="<?php echo $row['name'] ?> "> </input></td>
                    <td><?php echo $row['email'] ?></td>
                    <td><?php echo $row['login_platform'] ?></td>
                    <td><img src= <?php echo $row['profile_pic_url'] ?> width="30px" height="30px"></td>
                </form>
            </tr>
        <?php } ?>
    </table>
</center>

<center>
    <div class="pagination">
        <a href="#">&laquo;</a>
        <a href="#">1</a>
        <a href="#">2</a>
        <a href="#">3</a>
        <a href="#">4</a>
        <a href="#">5</a>
        <a href="#">6</a>
        <a href="#">&raquo;</a>
    </div>
</center>


<!-- Sticky Footer -->
<footer class="sticky-footer">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright © Your Website 2018</span>
        </div>
    </div>
</footer>

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="login.html">Logout</a>
            </div>
        </div>
    </div>
</div>

</body>

</html>
```