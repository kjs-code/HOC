# 웹으로 지도 연동하기

웹지도 연동은 생각보다 상당히 간단하다.
구글에서 검색해서 붙여넣기만 한건데 잘 동작을해서 따로 구현방법에대한
설명은 필요없을 것 같다.

```
<!-- 지도 -->
<div id="googleMap" style="width:40%; height:500px; margin-top: 20px"></div>

<script>
    function myMap() {

        var myLatLng = new google.maps.LatLng(<?php echo $restaurant->lat ?>,<?php echo $restaurant->lon ?>);


        var mapProp = {
            center: myLatLng,
            zoom: 17,
        };
        var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);

        var marker = new google.maps.Marker({
            position: myLatLng,
            title: "Hello World!"
        });

        marker.setMap(map);
    }
</script>
```