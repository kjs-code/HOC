
# 맛집찾기 구현

# 맛집찾기 ERD
```
[Restaurant] - <located> - [region] - <소속> - [city]
(restaurant_id)            (region_id)        (city_id)
(restaurant_name)          (region_name)      (city_name)
(hit)
(fav)
(writing)
(avg)
(introduce)
(address)
(lat)
(lon)
(tel)
(holiday)
(price)
(food_category)
(parking_information)
(conv_update_date)
(menu1)
(menu1_price)
(menu2)
(menu2_price)
(menu3)
(menu3_price)
(menu_image)
(keyworkd)

```
