package com.study.restaurant;

import android.content.Context;
import android.content.res.Resources;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.study.restaurant.api.ApiManager;
import com.study.restaurant.model.News;
import com.study.restaurant.model.Store;
import com.study.restaurant.model.StoreDetailResponseBody;
import com.study.restaurant.model.StorePicture;
import com.study.restaurant.model.StoreSpec;
import com.study.restaurant.model.Story;
import com.study.restaurant.test.Dummy;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;

import static junit.framework.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class AndroidTest {

    @Test
    public void test() {
        try {
            Context appContext = InstrumentationRegistry.getTargetContext();
            Resources res = appContext.getResources();
            InputStream in_s = res.openRawResource(R.raw.store_spec_dummy);

            byte[] b = new byte[in_s.available()];
            in_s.read(b);
            String s = new String(b);
            //System.out.println(s);

            StoreSpec storeSpec = new Gson().fromJson(s, StoreSpec.class);

            System.out.println(storeSpec.getImg1().getImg1());


        } catch (Exception e) {
            // e.printStackTrace();
            System.out.println(e.toString());
        }
        assertEquals("!!", "!!");
    }

    @Test
    public void retrofitTest() {
        ApiManager.getInstance().getStory(new ApiManager.CallbackListener() {
            @Override
            public void callback(String result) {
                System.out.println(result);
                try {
                    Type listType = new TypeToken<ArrayList<Story>>() {
                    }.getType();
                    ArrayList<Story> story = new Gson().fromJson(result, listType);
                    System.out.println(story.get(0).toString());
                } catch (Exception e) {
                }
            }

            @Override
            public void failed(String msg) {

            }
        });
    }

    @Test
    public void restaurantListDummyTest() {
        Context appContext = InstrumentationRegistry.getTargetContext();
        Dummy.getInstance().setContext(appContext);
    }

    @Test
    public void restaurantDetailDummyTest() {
        Context appContext = InstrumentationRegistry.getTargetContext();
        Dummy.getInstance().setContext(appContext);
        String dummy = Dummy.getInstance().getRestaurantDetail();
        StoreDetailResponseBody storeDetailResponseBody = new Gson().fromJson(dummy, StoreDetailResponseBody.class);
        String s = storeDetailResponseBody.getOpen_hours().getOffDay();
        storeDetailResponseBody.getRestaurant();
    }

    @Test
    public void addFavoriteDummyTest() {
        Context appContext = InstrumentationRegistry.getTargetContext();
        Dummy.getInstance().setContext(appContext);
        Store store = new Gson().fromJson(Dummy.getInstance().getAddFavorite(), Store.class);
        assertEquals("1", store.getFavority_id());
    }

    @Test
    public void newTest() {
        //String dummy1 = "{\"create_date\":\"2019-05-08 18:27:55\",\"storePictures\":\"[{\\\"pic_id\\\":\\\"488885\\\"}]\"}";
        String dummy1 = "{\"storePictures\":[{\"pic_id\":\"488885\"}]}";
        String str1 = "[{\"pic_id\":\"488885\"}]";
        String str = "";

        try {
            str = new JSONObject(dummy1).getString("storePictures");
            JSONArray arr = new JSONObject(dummy1).getJSONArray("storePictures");

            JSONArray array = new JSONArray(str);
        } catch (Exception e) {
            e.printStackTrace();
        }

        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject1 = new JSONObject();
        try {
            jsonObject1.put("pic_id", "488885");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        jsonArray.put(jsonObject1);
        try {
            jsonObject.put("storePicture", jsonArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String strrrr = jsonObject.toString();

        News news = new News();
        ArrayList<StorePicture> array = new ArrayList<>();
        StorePicture pic = new StorePicture();
        pic.setPic_id("1");
        pic.setNumber("2");
        pic.setDate("3");
        pic.setPic_url("4");
        pic.setUser_id("5");
        pic.setStore_id("6");
        array.add(pic);
        news.setStorePictures(array);

        String str12 = new Gson().toJson(news);


    }
}
