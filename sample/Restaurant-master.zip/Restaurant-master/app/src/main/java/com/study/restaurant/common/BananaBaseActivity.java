package com.study.restaurant.common;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.study.restaurant.R;
import com.study.restaurant.util.Logger;

public abstract class BananaBaseActivity<B extends ViewDataBinding, V extends ViewModel> extends AppCompatActivity {

    protected B mBinding;
    protected V mViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banana_base);
        mBinding = DataBindingUtil.inflate(getLayoutInflater(), getLayoutId(), null, false);
        if (getViewModelClass() != null)
            mViewModel = ViewModelProviders.of(this).get(getViewModelClass());

        if (mBinding == null) {
            getLayoutInflater().inflate(getLayoutId(), findViewById(R.id.child_layout));
        }
        else {
            mBinding.setLifecycleOwner(this);
            ((FrameLayout) findViewById(R.id.child_layout)).addView(mBinding.getRoot());
        }
        Logger.v("enter:" + getClass().getSimpleName());
        ((TextView) findViewById(R.id.name)).setText(getClass().getSimpleName());
    }

    public void clickClose(View v) {
        onBackPressed();
    }

    protected abstract int getLayoutId();

    protected abstract Class<V> getViewModelClass();

}
