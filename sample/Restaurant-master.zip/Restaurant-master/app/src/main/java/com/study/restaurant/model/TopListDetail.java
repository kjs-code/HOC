package com.study.restaurant.model;

public class TopListDetail{

    private String toplist_detail_id;
    private String top_list_id;
    private String store_id;
    private String image;
    private String number;
    private String store_name;
    private String score;
    private String address;
    private String profile_pic;
    private String reply_user_name;
    private String reply_contents;

    public String getToplist_detail_id() {
        return toplist_detail_id;
    }

    public void setToplist_detail_id(String toplist_detail_id) {
        this.toplist_detail_id = toplist_detail_id;
    }

    public String getTop_list_id() {
        return top_list_id;
    }

    public void setTop_list_id(String top_list_id) {
        this.top_list_id = top_list_id;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getStore_name() {
        return store_name;
    }

    public void setStore_name(String store_name) {
        this.store_name = store_name;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProfile_pic() {
        return profile_pic;
    }

    public void setProfile_pic(String profile_pic) {
        this.profile_pic = profile_pic;
    }

    public String getReply_user_name() {
        return reply_user_name;
    }

    public void setReply_user_name(String reply_user_name) {
        this.reply_user_name = reply_user_name;
    }

    public String getReply_contents() {
        return reply_contents;
    }

    public void setReply_contents(String reply_contents) {
        this.reply_contents = reply_contents;
    }

    public TopListDetail() {
    }

} // =========================================================  class TopListContents