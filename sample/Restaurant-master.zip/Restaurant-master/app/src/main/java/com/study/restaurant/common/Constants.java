package com.study.restaurant.common;

public class Constants {

    public static String API_URL = "http://sarang628.iptime.org:83/";
    //    public static String API_URL = "http://192.168.2.34:8888/banana_server/";

    public static String IMG_URL = "http://sarang628.iptime.org:83/image_upload/";
}
