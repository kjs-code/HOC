package com.study.restaurant.ui.picturereview;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.study.restaurant.model.News;
import com.study.restaurant.model.StorePicture;

public class PicReviewDetailViewModel extends ViewModel {
    // TODO: Implement the ViewModel
    News news;
    public MutableLiveData<String> picUrl = new MutableLiveData<>();
    public MutableLiveData<String> contents = new MutableLiveData<>();
    public MutableLiveData<String> date = new MutableLiveData<>();
    boolean isExistsHeart_id = false;

    public boolean isExistsHeart_id() {
        return isExistsHeart_id;
    }

    public void setNews(News news) {
        this.news = news;
        picUrl.setValue(news.getStorePictures().get(0).getPic_url());
        contents.setValue(news.getContents());
        date.setValue(news.getDate());
    }

    public News getNews() {
        return news;
    }

    public void clickProfile(String user_id) {

    }

    public void clickLike(String news_id) {

    }
}
