package com.study.restaurant.view;

public interface RegisterRestaurantNavigator {
    void goMap();

    void onFinish();
}
