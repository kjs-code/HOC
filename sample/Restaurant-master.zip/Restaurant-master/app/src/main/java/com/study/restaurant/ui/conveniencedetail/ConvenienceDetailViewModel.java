package com.study.restaurant.ui.conveniencedetail;

import android.arch.lifecycle.ViewModel;

import com.study.restaurant.model.Store;
import com.study.restaurant.util.Logger;

public class ConvenienceDetailViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    public void clickProvideIncorrect(Store store) {
        Logger.v("clickProvideIncorrect");
    }
}
