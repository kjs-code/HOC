package com.study.restaurant.ui.picturereview;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

import com.study.restaurant.R;
import com.study.restaurant.api.ApiManager;
import com.study.restaurant.model.News;
import com.study.restaurant.model.Review;
import com.study.restaurant.model.StorePicture;

import java.util.ArrayList;

/**
 {@link R.layout#picture_review_fragment}
 */
public class PictureReviewViewModel extends ViewModel {

    public MutableLiveData<String> profilePicUrl = new MutableLiveData<>();
    public MutableLiveData<String> userName = new MutableLiveData<>();
    public MutableLiveData<String> userReviewCount = new MutableLiveData<>();
    public MutableLiveData<String> userFollowerCount = new MutableLiveData<>();

    private PicRvwPgrAdt picRvwPgrAdt;

    public ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            News news = picRvwPgrAdt.getNews().get(position);
            userName.setValue(news.getName());
            profilePicUrl.setValue(news.getProfile_pic_url());
            userReviewCount.setValue("" + position);
            userFollowerCount.setValue("" + position);
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };


    public void appendNews(ArrayList<News> news) {
        picRvwPgrAdt.addStorePictures(news);
    }

    public MutableLiveData<Boolean> isExistsHeart_id = new MutableLiveData<>();

    public void pagerAdapterInit(FragmentManager fragmentManager) {
        picRvwPgrAdt = new PicRvwPgrAdt(fragmentManager);
    }

    public PicRvwPgrAdt getPicRvwPgrAdt() {
        return picRvwPgrAdt;
    }

    public void clickProfile(String userId) {

    }

    public void clickLike(View v, String news_id) {
        if (v.isSelected()) {
            ApiManager.getInstance().deleteLikeReview(v.getContext(), news_id, new ApiManager.CallbackListener() {
                @Override
                public void callback(String result) {
                    isExistsHeart_id.setValue(false);
                }

                @Override
                public void failed(String msg) {

                }
            });
        }
        else {
            ApiManager.getInstance().addLikeReview(v.getContext(), news_id, new ApiManager.CallbackListener() {
                @Override
                public void callback(String result) {
                    isExistsHeart_id.setValue(true);
                }

                @Override
                public void failed(String msg) {

                }
            });
        }

    }

    public void clickShare(Review review) {

    }

    public void clickMore(Review review) {

    }

    public View.OnClickListener getPhotoViewerListener() {
        return view -> {

        };
    }
}
