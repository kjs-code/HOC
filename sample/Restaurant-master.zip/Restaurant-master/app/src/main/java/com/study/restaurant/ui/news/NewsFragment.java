package com.study.restaurant.ui.news;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.study.restaurant.R;
import com.study.restaurant.databinding.FragmentNewsBinding;
import com.study.restaurant.ui.BananaBaseFragment;
import com.study.restaurant.ui.newslist.NewsListFragment;

public class NewsFragment extends BananaBaseFragment<FragmentNewsBinding, NewsViewModel> {

    /**
     뉴스 뷰페이저
     */
    ViewPager newsVp;

    /**
     뉴스 탭레이아웃
     */
    TabLayout tlNews;

    public NewsFragment() {
        // Required empty public constructor
    }

    public static NewsFragment newInstance() {
        NewsFragment fragment = new NewsFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    protected View getContainer() {
        return null;
    }

    @Override
    protected View getPlaceHolder() {
        return null;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_news;
    }

    @Override
    protected Class<NewsViewModel> getVmClass() {
        return NewsViewModel.class;
    }

    @Override
    public void uiInit() {
        newsVp = mDataBinding.newsVp;
        tlNews = mDataBinding.tlNews;

        newsVp.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tlNews));
        tlNews.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                newsVp.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        newsVp.setAdapter(new NewsVpAdt(getFragmentManager()));
    }

    @Override
    public void doProcess() {

    }

    private class NewsVpAdt extends FragmentStatePagerAdapter {
        public NewsVpAdt(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return new NewsListFragment();
        }

        @Override
        public int getCount() {
            return tlNews.getTabCount();
        }
    }
}
