package com.study.restaurant.ui.newslist;

import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.study.restaurant.R;
import com.study.restaurant.adapter.ReviewRvAdt;
import com.study.restaurant.api.ApiManager;
import com.study.restaurant.databinding.FragmentNewsListBinding;
import com.study.restaurant.model.News;
import com.study.restaurant.ui.BananaBaseFragment;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 소식 리스트
 */
public class NewsListFragment extends BananaBaseFragment<FragmentNewsListBinding, NewsListViewModel> {

    RecyclerView rvNewsList;
    SwipeRefreshLayout srlNewsList;

    public NewsListFragment() {
        // Required empty public constructor
    }

    public static NewsListFragment newInstance() {
        NewsListFragment fragment = new NewsListFragment();
        return fragment;
    }

    /**
     life cycle
     */

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /**
     abstract base fragment
     */

    @Override
    protected View getContainer() {
        return null;
    }

    @Override
    protected View getPlaceHolder() {
        return null;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_news_list;
    }

    @Override
    protected Class<NewsListViewModel> getVmClass() {
        return NewsListViewModel.class;
    }

    @Override
    public void uiInit() {
        rvNewsList = mDataBinding.rvNewsList;
        rvNewsList.setAdapter(new ReviewRvAdt() {
            @Override
            public void clickPicture(News news) {

            }
        });
        rvNewsList.setLayoutManager(new LinearLayoutManager(getContext()));
        rvNewsList.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                super.getItemOffsets(outRect, view, parent, state);
                outRect.left = 40;
                outRect.right = 40;
                outRect.top = 40;
            }
        });

        srlNewsList = mDataBinding.srlNewsList;
        srlNewsList.setOnRefreshListener(() -> requestNews());
    }

    @Override
    public void doProcess() {
        requestNews();
    }

    /**
     api
     */

    void requestNews() {
        //뉴스 피드 요청하기
        Map<String, String> param = new HashMap<>();
        ApiManager.getInstance().getNews(param, new ApiManager.CallbackListener() {
            @Override
            public void callback(String result) {
                Type type = new TypeToken<ArrayList<News>>() {
                }.getType();
                ArrayList<News> newsArrayList = new Gson().fromJson(result, type);
                ((ReviewRvAdt) rvNewsList.getAdapter()).setNewsList(newsArrayList);
                srlNewsList.setRefreshing(false);
            }

            @Override
            public void failed(String msg) {
                Toast.makeText(getContext(), "소식 요청에 실패하였습니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

