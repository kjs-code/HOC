package com.study.restaurant.view;

public interface SelectRegionPopupView{
    void validateButton(boolean isValiate);
}