package com.study.restaurant.ui.findrestaurantview;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.location.Location;
import android.view.View;
import android.widget.Toast;

import com.study.restaurant.api.ApiManager;
import com.study.restaurant.common.BananaPreference;
import com.study.restaurant.model.Boundary;
import com.study.restaurant.model.Cities;
import com.study.restaurant.model.FindRestaurant;
import com.study.restaurant.model.Store;
import com.study.restaurant.navigation.BananaNavigation;

import java.util.ArrayList;

/**
 FindRestaurantFragment 에서 사용
 */
public class FindRestaurantViewModel extends ViewModel {
    private BananaNavigation.FindRestaurantNavigation findRestaurantNavigation;
    private FindRestaurant findRestaurant;
    private MutableLiveData<Boolean> isVisibleTopButton = new MutableLiveData<>();

    public FindRestaurantViewModel() {
        isVisibleTopButton.setValue(false);
    }

    public void setFindRestaurantNavigation(BananaNavigation.FindRestaurantNavigation findRestaurantNavigation) {
        this.findRestaurantNavigation = findRestaurantNavigation;
    }

    public MutableLiveData<Boolean> isVisibleTopButton() {
        return isVisibleTopButton;
    }

    public void setVisibleTopButton(boolean visibleTopButton) {
        if (visibleTopButton != isVisibleTopButton.getValue())
            isVisibleTopButton.setValue(visibleTopButton);
    }

    public Object getRvItem(int position) {
        if (position > 1) {
            return findRestaurant.getStoreArrayList().get(position - 2);
        }
        else {
            return null;
        }
    }

    public int getRvCount() {
        return 2 + findRestaurant.getStoreArrayList().size();
    }

    public FindRestaurant getFindRestaurant() {
        return findRestaurant;
    }

    public void clickSelectLocation(View v) {
        findRestaurantNavigation.showSelectRegionPopup();
    }

    public void addStoreArrayList(ArrayList<Store> storeArrayList) {
        findRestaurant.addAllStoreArrayList(storeArrayList);
    }

    public void setFindRestaurant(FindRestaurant findRestaurant) {
        this.findRestaurant = findRestaurant;
    }


    public void clickSearch(View v) {
        findRestaurantNavigation.goSearch();
    }

    public void clickSort(View v) {
        findRestaurantNavigation.showSortPopup();
    }

    public void clickBoundary(View v) {
        //내 주변을 클릭 시 기존 선택된 도시가 모두 해제된다.
        Boundary boundary = findRestaurant.getBoundary();
        Cities cities = findRestaurant.getCities();
        if (boundary.getBoundary().equals("내 주변")) {
            cities.releaseAllSelected();
            boundary.setLevel3(true);

            //removeAllStore();
            //requestStoreSummary();
        }
        else {
            findRestaurantNavigation.showBoundaryPopup();
        }
    }

    public void clickFilter(View v) {
        findRestaurantNavigation.showFilterPopup();
    }


    public void removeAllStore() {
        findRestaurant.getStoreArrayList().removeAll(findRestaurant.getStoreArrayList());

    }

    public void clickRestaurant(View v) {
        findRestaurantNavigation.goDeatilRestaurant((Store) v.getTag());
    }

    public void clickToTop(View v) {
        findRestaurantNavigation.rvToTop();
        setVisibleTopButton(false);
    }

    public void setMyLocation(Location myLocation) {
        findRestaurant.setMyLocation(myLocation);
    }

    public void clickFavorite(View v, Store store) {
        if (!BananaPreference.getInstance(v.getContext()).loadUser().isLogin()) {
            Toast.makeText(v.getContext(), "로그인 해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (store.isExistsFavority_id()) {
            ApiManager.getInstance().deleteFavorite(v.getContext(), store);
        }
        else {
            ApiManager.getInstance().addFavorite(v.getContext(), store);
        }
    }
}
