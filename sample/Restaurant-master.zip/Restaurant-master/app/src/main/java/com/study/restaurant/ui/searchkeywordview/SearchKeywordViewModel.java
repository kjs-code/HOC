package com.study.restaurant.ui.searchkeywordview;

import android.arch.lifecycle.ViewModel;

public class SearchKeywordViewModel extends ViewModel {
}
