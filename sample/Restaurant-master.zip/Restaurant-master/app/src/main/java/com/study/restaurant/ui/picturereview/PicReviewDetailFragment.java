package com.study.restaurant.ui.picturereview;

import android.view.View;

import com.study.restaurant.R;
import com.study.restaurant.databinding.PicReviewDetailFragmentBinding;
import com.study.restaurant.model.News;
import com.study.restaurant.ui.BananaBaseFragment;

/**
 사진 리뷰 상세화면
 */
public class PicReviewDetailFragment extends BananaBaseFragment<PicReviewDetailFragmentBinding, PicReviewDetailViewModel> {

    public static PicReviewDetailFragment newInstance() {
        return new PicReviewDetailFragment();
    }

    @Override
    protected View getContainer() {
        return null;
    }

    @Override
    protected View getPlaceHolder() {
        return null;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.pic_review_detail_fragment;
    }

    @Override
    protected Class<PicReviewDetailViewModel> getVmClass() {
        return PicReviewDetailViewModel.class;
    }

    @Override
    public void uiInit() {
        mViewModel.setNews(news);
        mDataBinding.setVm(mViewModel);
    }

    @Override
    public void doProcess() {

    }

    private News news;

    public void setNews(News news) {
        this.news = news;
    }
}
