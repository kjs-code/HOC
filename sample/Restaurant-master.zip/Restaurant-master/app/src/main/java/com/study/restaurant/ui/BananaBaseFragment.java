package com.study.restaurant.ui;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.study.restaurant.R;

public abstract class BananaBaseFragment<V extends ViewDataBinding, M extends ViewModel> extends Fragment {
    protected V mDataBinding;
    protected M mViewModel;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_banana_base, null);
        mDataBinding = DataBindingUtil.inflate(LayoutInflater.from(getContext()), getLayoutId(), container, false);
        mDataBinding.setLifecycleOwner(this);
        ((FrameLayout) view.findViewById(R.id.fragment_child)).addView(mDataBinding.getRoot());
        ((TextView) view.findViewById(R.id.fragment_name)).setText(getClass().getSimpleName());
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(getVmClass());
        if (getPlaceHolder() != null)
            getPlaceHolder().setVisibility(View.GONE);
        ViewTreeObserver.OnGlobalLayoutListener layoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                mDataBinding.getRoot().getViewTreeObserver().removeOnGlobalLayoutListener(this);
                if (getPlaceHolder() != null)
                    showPlaceHolder();
                uiInit();
                doProcess();
            }
        };
        mDataBinding.getRoot().getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);
    }

    protected abstract View getContainer();

    protected abstract View getPlaceHolder();

    protected abstract int getLayoutId();

    protected abstract Class<M> getVmClass();

    public abstract void uiInit();

    public abstract void doProcess();

    public void hidePlaceHolder() {
        getPlaceHolder().startAnimation(AnimationUtils.loadAnimation(getPlaceHolder().getContext(), R.anim.fade_out));
        getPlaceHolder().setVisibility(View.GONE);
    }

    public void showPlaceHolder() {
        getPlaceHolder().startAnimation(AnimationUtils.loadAnimation(getPlaceHolder().getContext(), R.anim.fade_in));
        getPlaceHolder().setVisibility(View.VISIBLE);
    }
}
