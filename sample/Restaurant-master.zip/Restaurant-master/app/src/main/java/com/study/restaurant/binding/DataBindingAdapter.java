package com.study.restaurant.binding;

import android.databinding.BindingAdapter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.study.restaurant.adapter.AroundRestaurantRvAdt;
import com.study.restaurant.adapter.StoreRvAdt;
import com.study.restaurant.adapter.StoryRvAdt;
import com.study.restaurant.adapter.TopListRvAdt;
import com.study.restaurant.custom.BananaRecyclerView;
import com.study.restaurant.model.Store;
import com.study.restaurant.model.Story;
import com.study.restaurant.model.TopList;
import com.study.restaurant.util.MyGlide;
import com.study.restaurant.ui.findrestaurantview.FindRestaurantViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import jp.wasabeef.glide.transformations.BlurTransformation;

import static com.study.restaurant.util.GlideOptions.bitmapTransform;

public class DataBindingAdapter {
    @BindingAdapter({"app:onScrollListener"})
    public static void bind(RecyclerView recyclerView
            , RecyclerView.OnScrollListener onScrollListener) {
        if (onScrollListener != null)
            recyclerView.addOnScrollListener(onScrollListener);
    }

    @BindingAdapter({"app:adapter"})
    public static void setAdapterBind(RecyclerView recyclerView
            , RecyclerView.Adapter rvAdt) {
        recyclerView.setAdapter(rvAdt);
    }

    @BindingAdapter({"app:enabled"})
    public static void setEanbledBind(ViewGroup viewGroup, boolean b) {
        viewGroup.setEnabled(b);
    }

    @BindingAdapter({"app:items"})
    public static void setItemsBind1(RecyclerView recyclerView
            , ArrayList<TopList> items) {
        ((TopListRvAdt) recyclerView.getAdapter()).setTopLists(items);
    }

    @BindingAdapter({"app:items"})
    public static void setItemsBind2(RecyclerView recyclerView
            , ArrayList<Store> items) {
        ((AroundRestaurantRvAdt) recyclerView.getAdapter()).setStoreList(items);
    }

    @BindingAdapter({"app:items"})
    public static void setItemsBind3(RecyclerView recyclerView
            , ArrayList<Story> items) {
        ((StoryRvAdt) recyclerView.getAdapter()).setStoryList(items);
    }

    @BindingAdapter({"app:setSpanSizeLookup"})
    public static void spanSizeLookupBind(RecyclerView recyclerView, GridLayoutManager.SpanSizeLookup spanSizeLookup) {
        ((GridLayoutManager) recyclerView.getLayoutManager()).setSpanSizeLookup(spanSizeLookup);
    }

    @BindingAdapter({"app:spanCount"})
    public static void spanCountBind(RecyclerView recyclerView, int count) {
        ((GridLayoutManager) recyclerView.getLayoutManager()).setSpanCount(count);
    }

    @BindingAdapter({"app:selected"})
    public static void selectedBind(ViewGroup viewGroup
            , boolean selected
    ) {
        viewGroup.setSelected(selected);
    }

    @BindingAdapter({"app:onPageChangeListener"})
    public static void pageChangeBind(ViewPager viewPager, ViewPager.OnPageChangeListener onPageChangeListener) {
        viewPager.addOnPageChangeListener(onPageChangeListener);
    }

    @BindingAdapter({"app:offscreenPageLimit"})
    public static void pageLimitBind(ViewPager viewPager, int limit) {
        viewPager.setOffscreenPageLimit(limit);
    }

    @BindingAdapter({"app:glideLoadImage"})
    public static void glideLoadImage(ImageView imageView, String url) {
        MyGlide.with(imageView.getContext())
                .load(url)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView);
    }

    @BindingAdapter({"app:glideBlurImage"})
    public static void glideBlurImage(ImageView imageView, String url) {
        MyGlide.with(imageView.getContext())
                .load(url)
                .apply(bitmapTransform(new BlurTransformation(25, 3)))
                //.transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView);
    }

    @BindingAdapter({"app:textWhatcher"})
    public static void setTextWhatcher(EditText editText, TextWatcher textWatcher) {
        editText.addTextChangedListener(textWatcher);
    }

    @BindingAdapter({"app:setUnderLine"})
    public static void setPaintFlags(TextView textView, boolean b) {
        if (b) {
            textView.setPaintFlags(textView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        }
        else {
            textView.setPaintFlags(textView.getPaintFlags() & Paint.UNDERLINE_TEXT_FLAG);
        }
    }

    @BindingAdapter("app:setPagerAdater")
    public static void setPagerAdapter(ViewPager viewPager, FragmentStatePagerAdapter adapter) {
        viewPager.setAdapter(adapter);
    }

    @BindingAdapter("app:visibility")
    public static void setVisibility(View view, Boolean value) {
        view.setVisibility(value ? View.VISIBLE : View.GONE);
    }

    @BindingAdapter("app:refreshListener")
    public static void setRefreshListener(SwipeRefreshLayout swipeRefreshLayout,
                                          SwipeRefreshLayout.OnRefreshListener refreshListener) {
        swipeRefreshLayout.setOnRefreshListener(refreshListener);

    }

    @BindingAdapter({"app:glideRoundedLoadImage"})
    public static void glideRoundedLoadImage(ImageView imageView, String url) {
        MyGlide.with(imageView.getContext())
                .load(url)
                .transition(DrawableTransitionOptions.withCrossFade())
                .apply(RequestOptions.circleCropTransform())
                .into(imageView);
    }

    @BindingAdapter("app:setDate")
    public String setDate(TextView tv, String request_date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss"); try {
            long diff = System.currentTimeMillis() - simpleDateFormat.parse(request_date).getTime();
            int dayDiff = (int) (diff / (1000 * 60 * 60 * 24));
            int hourDiff = (int) (diff / (1000 * 60 * 60));
            int minDiff = (int) (diff / (1000 * 60)) + 6; if (dayDiff > 7) {
                return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(simpleDateFormat.parse(request_date).getTime());
            } if (hourDiff > 24) {
                return dayDiff + "일 전";
            } if (minDiff > 60) {
                return hourDiff + "시간 전";
            } return minDiff + "분 전";
        } catch (ParseException e) {
        } return "";
    }

    @BindingAdapter("app:setPagerAdt")
    public static void setPagerAdt(ViewPager viewPager, FragmentStatePagerAdapter adapter) {
        if (viewPager != null && adapter != null)
            viewPager.setAdapter(adapter);
    }

    @BindingAdapter("app:itemRightMargin")
    public static void itemRightMargin(RecyclerView recyclerView, Integer rightMargin) {
        recyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
            /**
             Retrieve any offsets for the given item. Each field of <code>outRect</code> specifies
             the number of pixels that the item view should be inset by, similar to padding or margin.
             The default implementation sets the bounds of outRect to 0 and returns.

             <p>
             If this ItemDecoration does not affect the positioning of item views, it should set
             all four fields of <code>outRect</code> (left, top, right, bottom) to zero
             before returning.

             <p>
             If you need to access Adapter for additional data, you can call
             {@link RecyclerView#getChildAdapterPosition(View)} to get the adapter position of the
             View.

             @param outRect Rect to receive the output.
             @param view    The child view to decorate
             @param parent  RecyclerView this ItemDecoration is decorating
             @param state   The current state of RecyclerView.
             */
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                super.getItemOffsets(outRect, view, parent, state);
                outRect.right = rightMargin;
            }
        });
    }
}
