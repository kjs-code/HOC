package com.study.restaurant.ui.findrestaurantview;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.study.restaurant.R;
import com.study.restaurant.adapter.StoreRvAdt;
import com.study.restaurant.common.BananaPreference;
import com.study.restaurant.ui.BananaBaseFragment;
import com.study.restaurant.ui.GlobalApplication;
import com.study.restaurant.ui.restaurantdetailview.RestaurantDetailActivity;
import com.study.restaurant.ui.searchview.SearchActivity;
import com.study.restaurant.api.ApiManager;
import com.study.restaurant.databinding.FragmentFindRestaurantBinding;
import com.study.restaurant.manager.MyLocationManager;
import com.study.restaurant.model.Region;
import com.study.restaurant.model.Store;
import com.study.restaurant.navigation.BananaNavigation;
import com.study.restaurant.popup.SelectDistancePopup;
import com.study.restaurant.popup.SelectFilterPoppupActivity;
import com.study.restaurant.popup.SelectRegionPopupActivity;
import com.study.restaurant.popup.SelectSortPopupActivity;
import com.study.restaurant.util.Logger;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.study.restaurant.adapter.ProgressRvAdt.VIEW_TYPE_PROGRESS;
import static com.study.restaurant.adapter.StoreRvAdt.VIEW_TYPE_BANNER;
import static com.study.restaurant.adapter.StoreRvAdt.VIEW_TYPE_MENU;

/**
 맛집 찾기 화면
 Documents : find_restaurant.md
 Layout    : {@link FragmentFindRestaurantBinding}
 View model: {@link FindRestaurantViewModel}

 {@link #uiInit()}
 {@link #doProcess()}
 {@link #requestLocation(RequestLocationListener)} ()}
 {@link #requestAddress(double, double, OnReceiveRegionListener)} ()}

 */
public class FindRestaurantFragment
        extends BananaBaseFragment<FragmentFindRestaurantBinding, FindRestaurantViewModel>
        implements BananaNavigation.FindRestaurantNavigation {

    public static FindRestaurantFragment newInstance() {
        FindRestaurantFragment fragment = new FindRestaurantFragment(); return fragment;
    }

    /** 위치 기능 관리 */
    private MyLocationManager myLocationManager;
    private StoreRvAdt storeRvAdt = new StoreRvAdt();

    /** abstract method */

    @Override
    protected View getContainer() { return mDataBinding.container; }

    @Override
    protected View getPlaceHolder() { return mDataBinding.placeHolder; }

    @Override
    protected int getLayoutId() { return R.layout.fragment_find_restaurant; }

    @Override
    protected Class<FindRestaurantViewModel> getVmClass() { return FindRestaurantViewModel.class; }

    @Override
    public void uiInit() {
        //스크롤리스너 먼저 해줘야함
        mDataBinding.setRvAdt(storeRvAdt);
        storeRvAdt.setVm(mViewModel);
        mDataBinding.setSpanSizeLookup(getSpanSizeLookup());
        mDataBinding.setNavigation(this);
    }

    /**
     권한 얻어오면 다시 호출하므로 주의해서 수정하기
     */
    @Override
    public void doProcess() {
        /** 내 위치 요청하기 */
        Logger.d("화면 진입 위치 요청하기");
        Handler handler = new Handler(); handler.postDelayed(() ->
                requestLocation(new RequestLocationListener() {
                    @Override
                    public void noLocationPermission() {
                        Logger.d("권한없음 요청하기");
                        /** 권한이 없다면 권한 요청하기 */
                        myLocationManager.requestLocationPermissionPopup(0x02);
                    }

                    @Override
                    public void offGpsSensor() {
                        Logger.d("GPS 꺼짐");
                        processGetLocation(null);
                    }

                    @Override
                    public void onSuccess(Location location) {
                        processGetLocation(location);
                    }
                }), 1000);
    }

    private void processGetLocation(Location location) {
        Region region = new Region();
        region.setRegion_id("100");
        region.setRegion_name("전체 지역");
        mViewModel.getFindRestaurant().getCities().setCurrentRegion(region);

        if (location == null) {
            Logger.d("위치 찾기 실패");
            mDataBinding.location.setText(region.getRegion_name());
            hidePlaceHolder();
            return;
        }

        Logger.d("위치 찾음");
        // 뷰 모델에 내 위치 셋팅해주기 식당과 내위치 거리계산을 위함
        mViewModel.setMyLocation(location);
        // 현재 내 위치에 해당하는 지역 요청하기
        if (!requestAddress(location.getLatitude(), location.getLongitude(), region1 -> {
            // 타이틀바 지역명 변경하기
            mDataBinding.location.setText(region1.getRegion_name());
            mViewModel.getFindRestaurant().getCities().setCurrentRegion(region1);
            // 내위치 해당 지역 맛집 검색하기
            requestStoreSummary();
            hidePlaceHolder();
        })) {
            Logger.d("지역 없음");
            mDataBinding.location.setText(region.getRegion_name());
            //TODO::임시 지역 없어도 요청함
            requestStoreSummary();
            hidePlaceHolder();
        }
    }

    /** life cycle */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel.setFindRestaurantNavigation(this);
        mViewModel.setFindRestaurant(getGlobalApplication().getFindRestaurant());
        mDataBinding.setVm(mViewModel);
        myLocationManager = new MyLocationManager(getActivity());

    }


    /** 위치요청 결과 리스너 */
    public interface RequestLocationListener {
        void noLocationPermission();

        void offGpsSensor();

        void onSuccess(Location location);
    }

    public void requestLocation(RequestLocationListener requestLocationListener) {

        OnSuccessListener<? super Location> listener = (OnSuccessListener<Location>) location -> requestLocationListener.onSuccess(location);

        /** 사용 전 권한 체크 순서는 권한을 먼저 체크해줘야함 GPS는 권한없으면 켜저도 OFF상태 */
        if (!myLocationManager.isGrantedPermission()) {
            requestLocationListener.noLocationPermission();
        }
        else if (!myLocationManager.isGpsOn()) {
            requestLocationListener.offGpsSensor();
        }
        else {
            /** 권한이 허용되어있다면 위치요청 */
            Logger.d("위치요청하기");
            myLocationManager.getLastLocation(listener);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 0x02) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                /** 위치 다시 요청하기 */
                doProcess();
            }
            else {
                /** 권한 거부시 */
                Logger.d("권한 거부");
                processGetLocation(null);
            }
        }
    }

    @Override
    public void showSelectRegionPopup() { SelectRegionPopupActivity.show((AppCompatActivity) getActivity()); }

    @Override
    public void showSortPopup() { SelectSortPopupActivity.show((AppCompatActivity) getActivity()); }

    @Override
    public void showBoundaryPopup() { SelectDistancePopup.show((AppCompatActivity) getActivity()); }

    @Override
    public void showFilterPopup() { SelectFilterPoppupActivity.show((AppCompatActivity) getActivity()); }

    @Override
    public void goSearch() { SearchActivity.go((AppCompatActivity) getActivity()); }

    @Override
    public void goDeatilRestaurant(Store store) { RestaurantDetailActivity.go((AppCompatActivity) getActivity(), store); }

    @Override
    public void rvToTop() { mDataBinding.findRestaurantRv.scrollToPosition(0); }

    @Override
    public void showErrorPopup(String msg) {
        AlertDialog.Builder b = new AlertDialog.Builder(getContext()); b.setTitle("오류");
        b.setMessage("오류가 발생하였습니다. 오류코드: " + msg); b.show();
    }

    private GlobalApplication getGlobalApplication() {
        return (GlobalApplication) getActivity().getApplication();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == 0x01) {
                mDataBinding.setCities(((GlobalApplication) getActivity().getApplication()).getFindRestaurant().getCities());
                mViewModel.getFindRestaurant().getCities().setCurrentRegion(null);
                mViewModel.removeAllStore();
                storeRvAdt.notifyDataSetChanged();
                requestStoreSummary();
            }

            if (requestCode == 0x02 || requestCode == 0x03 || requestCode == 0x04) {
                mViewModel.removeAllStore();
                storeRvAdt.notifyDataSetChanged();
                requestStoreSummary();
            }
        }
    }

    public interface OnReceiveRegionListener {
        void onReceiveRegion(Region region);
    }

    public boolean requestAddress(double latitude, double longitude, OnReceiveRegionListener onReceiveRegionListener) {
        String zipCode = myLocationManager.getZipcode(latitude, longitude);
        if (zipCode == null || zipCode.equals("")) {
            return false;
        } Logger.d(zipCode);
        ApiManager.getInstance().getRegion(zipCode, new ApiManager.CallbackListener() {
            @Override
            public void callback(String result) {
                Logger.d(result);
                Type listType = new TypeToken<ArrayList<Region>>() {}.getType();
                List<Region> regionList = new Gson().fromJson(result, listType);
                if (regionList != null && regionList.size() > 0) {
                    onReceiveRegionListener.onReceiveRegion(regionList.get(0));
                }
            }

            @Override
            public void failed(String msg) {
                Logger.d(msg);
            }
        }); return true;
    }

    public GridLayoutManager.SpanSizeLookup getSpanSizeLookup() {
        return new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (storeRvAdt.getItemViewType(position) == VIEW_TYPE_PROGRESS)
                    return 2;

                if (VIEW_TYPE_BANNER == storeRvAdt.getItemViewType(position)) {
                    return 2;
                }

                if (storeRvAdt.getItemViewType(position) == VIEW_TYPE_MENU) {
                    return 2;
                }

                return 1;
            }
        };
    }

    @Override
    public void requestStoreSummary() {
        Logger.d("맛집 리스트 요청");

        HashMap<String, String> param = new HashMap<>();
        param.put("region_id", getGlobalApplication().getFindRestaurant().getCities().getSelectedRegionIds());
        //param.put("boundary", "3km");
        param.put("filter", "");
        param.put("category", "all");
        param.put("lat", "0");
        param.put("lon", "0");
        param.put("sort", getGlobalApplication().getFindRestaurant().getSort().getAttribute());
        param.put("total_count", "" + getGlobalApplication().getFindRestaurant().getStoreArrayList().size());
        param.put("user_id", BananaPreference.getInstance(getContext()).loadUser().isLogin() ?
                BananaPreference.getInstance(getContext()).loadUser().user_id : "-1");
        ApiManager.getInstance().getStoreSummary(param, new ApiManager.CallbackListener() {
            @Override
            public void callback(String result) {
                Logger.d(result);
                mDataBinding.findRestaurantRv.setLast(false);
                Type listType = new TypeToken<ArrayList<Store>>() {
                }.getType();
                List<Store> storeList = new Gson().fromJson(result, listType);
                /** 내 위치 넣어주기 */
                mViewModel.addStoreArrayList((ArrayList<Store>) storeList);
                storeRvAdt.notifyDataSetChanged();
            }

            @Override
            public void failed(String msg) {
                showErrorPopup(msg);
            }
        });

    }
}
