package com.study.restaurant.ui.picturereview;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.study.restaurant.model.News;

import java.util.ArrayList;

public class PicRvwPgrAdt extends FragmentStatePagerAdapter {

    private ArrayList<News> news = new ArrayList<>();


    public void addStorePictures(ArrayList<News> news) {
        this.news.addAll(news);
        notifyDataSetChanged();
    }

    public PicRvwPgrAdt(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        PicReviewDetailFragment fragment = PicReviewDetailFragment.newInstance();
        fragment.setNews(news.get(position));
        return fragment;
    }

    @Override
    public int getCount() {
        return news.size();
    }

    public ArrayList<News> getNews() {
        return news;
    }
}