package com.study.restaurant.adapter;

public class TestAdapter {
    private String abc;
    public TestAdapter(String abc){
        this.abc = abc;
    }
}
