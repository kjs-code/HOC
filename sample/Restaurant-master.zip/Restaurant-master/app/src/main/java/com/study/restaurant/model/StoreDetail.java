package com.study.restaurant.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

import com.study.restaurant.R;
import com.study.restaurant.ui.conveniencedetail.ConvenienceDetailActivity;
import com.study.restaurant.ui.menudetail.MenuDetailActivity;

import java.util.ArrayList;

public class StoreDetail implements Parcelable {
    private Store store;
    private OpenHours openHours;
    private ArrayList<StoreMenu> menus;
    private ArrayList<News> images = new ArrayList<>();
    private ArrayList<News> reviews = new ArrayList<>();

    public void setReviews(ArrayList<News> reviews) {
        this.reviews = reviews;
    }

    public ArrayList<News> getReviews() {
        return reviews;
    }

    public ArrayList<News> getImages() {
        return images;
    }

    public void setImages(ArrayList<News> images) {
        this.images = images;
    }

    public StoreDetail() {

    }

    protected StoreDetail(Parcel in) {
        store = in.readParcelable(Store.class.getClassLoader());
        openHours = in.readParcelable(OpenHours.class.getClassLoader());
        menus = in.createTypedArrayList(StoreMenu.CREATOR);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(store, flags);
        dest.writeParcelable(openHours, flags);
        dest.writeTypedList(menus);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<StoreDetail> CREATOR = new Creator<StoreDetail>() {
        @Override
        public StoreDetail createFromParcel(Parcel in) {
            return new StoreDetail(in);
        }

        @Override
        public StoreDetail[] newArray(int size) {
            return new StoreDetail[size];
        }
    };

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public OpenHours getOpenHours() {
        return openHours;
    }

    public void setOpenHours(OpenHours openHours) {
        this.openHours = openHours;
    }

    /**
     {@link R.layout#activity_restaurant_detail}

     @param v
     */
    public void moreConvenience(View v) {
        ConvenienceDetailActivity.go(v.getContext(), this);
    }

    public void moreMenu(View v) {
        MenuDetailActivity.go(v.getContext(), menus, store.getStoreName());
    }

    public ArrayList<StoreMenu> getMenus() {
        return menus;
    }

    public void setMenus(ArrayList<StoreMenu> menus) {
        this.menus = menus;
    }
}
