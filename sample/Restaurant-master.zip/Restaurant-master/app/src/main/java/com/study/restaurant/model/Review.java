package com.study.restaurant.model;

import java.util.ArrayList;

public class Review {
    String prifile_pic;
    String name;
    String review_count;
    String follower;
    String tag;
    String review;
    String img1;
    String img2;
    String img3;
    String img4;
    String img5;
    String like;
    String comment;
    String date;
    ArrayList<StorePicture> pictures;


    public String getPrifile_pic() {
        return prifile_pic;
    }

    public void setPrifile_pic(String prifile_pic) {
        this.prifile_pic = prifile_pic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReview_count() {
        return review_count;
    }

    public void setReview_count(String review_count) {
        this.review_count = review_count;
    }

    public String getFollower() {
        return follower;
    }

    public void setFollower(String follower) {
        this.follower = follower;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public boolean isHasImg1() {
        return (img1 == null || img1.length() == 0);
    }

    public String getImg1() {
        return img1;
    }

    public void setImg1(String img1) {
        this.img1 = img1;
    }

    public String getImg2() {
        return img2;
    }

    public void setImg2(String img2) {
        this.img2 = img2;
    }

    public String getImg3() {
        return img3;
    }

    public void setImg3(String img3) {
        this.img3 = img3;
    }

    public String getImg4() {
        return img4;
    }

    public void setImg4(String img4) {
        this.img4 = img4;
    }

    public String getImg5() {
        return img5;
    }

    public void setImg5(String img5) {
        this.img5 = img5;
    }

    public String getLike() {
        return like;
    }

    public void setLike(String like) {
        this.like = like;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public ArrayList<StorePicture> getPictures() {
        return pictures;
    }

    public void setPictures(ArrayList<StorePicture> pictures) {
        this.pictures = pictures;
    }
}