package com.study.restaurant.ui.newslist;

import android.arch.lifecycle.ViewModel;

public class NewsListViewModel extends ViewModel {
}
