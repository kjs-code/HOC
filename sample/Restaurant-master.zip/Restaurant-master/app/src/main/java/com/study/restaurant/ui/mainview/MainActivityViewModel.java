package com.study.restaurant.ui.mainview;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.support.v4.view.ViewPager;

import com.study.restaurant.navigation.BananaNavigation;

public class MainActivityViewModel extends ViewModel {
    public enum MainMenuType {
        FIND_RESTAURANT, MANGO_PICK, NEWS, MY_INFORMATION
    }

    private MutableLiveData<MainMenuType> selectedMenu = new MutableLiveData<>();
    private MutableLiveData<Boolean> isMenuEanbled = new MutableLiveData<>();
    private BananaNavigation.MainNavigation mainActivitytNavigation;

    public MainActivityViewModel() {
        selectedMenu.setValue(MainMenuType.FIND_RESTAURANT);
        isMenuEanbled.setValue(false);
    }

    public MutableLiveData<MainMenuType> getSelectedMenu() {
        return selectedMenu;
    }

    public void setMainActivitytNavigation(BananaNavigation.MainNavigation mainActivitytNavigation) {
        this.mainActivitytNavigation = mainActivitytNavigation;
    }

    public MutableLiveData<Boolean> getIsMenuEanbled() {
        return isMenuEanbled;
    }

    public void setMenuEanbled(boolean menuEanbled) {
        isMenuEanbled.setValue(menuEanbled);
    }

    public void clickFindRestaurant() {
        mainActivitytNavigation.goFindRestaurant();
        selectedMenu.setValue(MainMenuType.FIND_RESTAURANT);
    }


    public void clickMangoPick() {
        mainActivitytNavigation.goMangoPick();
        selectedMenu.setValue(MainMenuType.MANGO_PICK);
    }

    public void clickMyInformation() {
        mainActivitytNavigation.goMyInformation();
        selectedMenu.setValue(MainMenuType.MY_INFORMATION);
    }

    public void clickNews() {
        mainActivitytNavigation.goNews();
        selectedMenu.setValue(MainMenuType.NEWS);
    }

    /**
     하단 메뉴의 가운데 버튼을 클릭 시 등록화면 보여주는기능
     TODO::함수명 바꿔주기

     @param v
     */
    public void clickRegister() {
        showRegisterMenu(!isMenuEanbled.getValue());
    }

    public void showRegisterMenu(boolean b) {
        setMenuEanbled(b);
        mainActivitytNavigation.rotationMenu(b);
        if (b) {
            mainActivitytNavigation.registerShowAnimation();
        }
        else {
            mainActivitytNavigation.hideMenu();
        }
    }

    public ViewPager.OnPageChangeListener getOnPageChangeListener() {
        return new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        selectedMenu.setValue(MainMenuType.FIND_RESTAURANT);
                        break;
                    case 1:
                        selectedMenu.setValue(MainMenuType.MANGO_PICK);
                        break;
                    case 2:
                        selectedMenu.setValue(MainMenuType.NEWS);
                        break;
                    case 3:
                        selectedMenu.setValue(MainMenuType.MY_INFORMATION);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        };
    }

}
