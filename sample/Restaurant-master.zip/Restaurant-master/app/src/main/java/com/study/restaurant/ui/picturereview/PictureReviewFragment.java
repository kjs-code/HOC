package com.study.restaurant.ui.picturereview;

import android.os.Handler;
import android.view.View;

import com.study.restaurant.R;
import com.study.restaurant.databinding.PictureReviewFragmentBinding;
import com.study.restaurant.ui.BananaBaseFragment;

public class PictureReviewFragment extends BananaBaseFragment<PictureReviewFragmentBinding, PictureReviewViewModel> {

    public static PictureReviewFragment newInstance() {
        return new PictureReviewFragment();
    }

    @Override
    protected View getContainer() {
        return null;
    }

    @Override
    protected View getPlaceHolder() {
        return null;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.picture_review_fragment;
    }

    @Override
    protected Class<PictureReviewViewModel> getVmClass() {
        return PictureReviewViewModel.class;
    }

    @Override
    public void uiInit() {
        mViewModel.pagerAdapterInit(getActivity().getSupportFragmentManager());
        mViewModel.appendNews(getActivity().getIntent().getParcelableArrayListExtra("news"));
        mDataBinding.setVm(mViewModel);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mDataBinding.picVp.setCurrentItem(getActivity().getIntent().getIntExtra("position", 0));
            }
        },100);

    }

    @Override
    public void doProcess() {
    }
}
