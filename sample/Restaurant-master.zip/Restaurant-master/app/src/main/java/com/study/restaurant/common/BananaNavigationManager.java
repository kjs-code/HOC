package com.study.restaurant.common;

import android.content.Context;

public class BananaNavigationManager {
    public static void goLogin(Context context) {

    }
}
