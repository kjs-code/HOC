package com.study.restaurant.model;

import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.ViewGroup;

import java.util.ArrayList;

public class StoreDetailResponseBody extends BaseObservable implements Parcelable {
    private Store restaurant;
    private ArrayList<ImageBody> image;
    private ArrayList<News> reviews;
    private ArrayList<TopList> toplist;
    private ArrayList<Story> stories;
    private ArrayList<Store> store;
    private OpenHours open_hours = new OpenHours();
    private ArrayList<StoreMenu> menus;
    private ArrayList<StoreKeyword> keywords;
    private String review_total;
    private String review_best;
    private String review_good;
    private String review_bad;
    private ArrayList<BusinessHour> businessHours;

    public StoreDetail toStoreDetail() {
        StoreDetail storeDetail = new StoreDetail();
        storeDetail.setOpenHours(open_hours);
        storeDetail.setImages(getImageToNews());
        storeDetail.setStore(restaurant);
        storeDetail.setReviews(getReviews());
        return storeDetail;
    }


    public void businessToOpenHour() {
        for (int i = 0; i < businessHours.size(); i++) {
            switch (businessHours.get(i).day) {
                case 1:
                    open_hours.setMon_open(businessHours.get(i).start_hour);
                    open_hours.setMon_close(businessHours.get(i).close_hour);
                    break;
                case 2:
                    open_hours.setTue_open(businessHours.get(i).start_hour);
                    open_hours.setTue_close(businessHours.get(i).close_hour);
                    break;
                case 3:
                    open_hours.setWed_open(businessHours.get(i).start_hour);
                    open_hours.setWed_close(businessHours.get(i).close_hour);
                    break;
                case 4:
                    open_hours.setThu_open(businessHours.get(i).start_hour);
                    open_hours.setThu_close(businessHours.get(i).close_hour);
                    break;
                case 5:
                    open_hours.setFri_open(businessHours.get(i).start_hour);
                    open_hours.setFri_close(businessHours.get(i).close_hour);
                    break;
                case 6:
                    open_hours.setSat_open(businessHours.get(i).start_hour);
                    open_hours.setSat_close(businessHours.get(i).close_hour);
                    break;
                case 7:
                    open_hours.setSun_open(businessHours.get(i).start_hour);
                    open_hours.setSun_close(businessHours.get(i).close_hour);
                    break;
            }
        }
    }


    public StoreDetailResponseBody() {

    }

    protected StoreDetailResponseBody(Parcel in) {
        restaurant = in.readParcelable(Store.class.getClassLoader());
        toplist = in.createTypedArrayList(TopList.CREATOR);
        stories = in.createTypedArrayList(Story.CREATOR);
        store = in.createTypedArrayList(Store.CREATOR);
        open_hours = in.readParcelable(OpenHours.class.getClassLoader());
        menus = in.createTypedArrayList(StoreMenu.CREATOR);
        keywords = in.createTypedArrayList(StoreKeyword.CREATOR);
        review_total = in.readString();
        review_best = in.readString();
        review_good = in.readString();
        review_bad = in.readString();
        businessHours = in.createTypedArrayList(BusinessHour.CREATOR);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(restaurant, flags);
        dest.writeTypedList(toplist);
        dest.writeTypedList(stories);
        dest.writeTypedList(store);
        dest.writeParcelable(open_hours, flags);
        dest.writeTypedList(menus);
        dest.writeTypedList(keywords);
        dest.writeString(review_total);
        dest.writeString(review_best);
        dest.writeString(review_good);
        dest.writeString(review_bad);
        dest.writeTypedList(businessHours);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<StoreDetailResponseBody> CREATOR = new Creator<StoreDetailResponseBody>() {
        @Override
        public StoreDetailResponseBody createFromParcel(Parcel in) {
            return new StoreDetailResponseBody(in);
        }

        @Override
        public StoreDetailResponseBody[] newArray(int size) {
            return new StoreDetailResponseBody[size];
        }
    };

    public Store getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Store restaurant) {
        this.restaurant = restaurant;
    }

    public ArrayList<ImageBody> getImage() {
        return image;
    }

    public ArrayList<News> getImageToNews() {
        ArrayList<News> news = new ArrayList<>();

        for (int i = 0; i < image.size(); i++) {
            news.add(image.get(i).toNews());
        }

        return news;
    }

    public void setImage(ArrayList<ImageBody> image) {
        this.image = image;
    }

    public ArrayList<TopList> getToplist() {
        return toplist;
    }

    public void setToplist(ArrayList<TopList> toplist) {
        this.toplist = toplist;
    }

    public ArrayList<Store> getStore() {
        return store;
    }

    public void setStore(ArrayList<Store> store) {
        this.store = store;
    }

    public OpenHours getOpen_hours() {
        return open_hours;
    }

    public void setOpen_hours(OpenHours open_hours) {
        this.open_hours = open_hours;
    }

    public ArrayList<StoreMenu> getMenus() {
        return menus;
    }

    public void setMenus(ArrayList<StoreMenu> menus) {
        this.menus = menus;
    }

    public ArrayList<StoreKeyword> getKeywords() {
        return keywords;
    }

    public void setKeywords(ArrayList<StoreKeyword> keywords) {
        this.keywords = keywords;
    }

    public ArrayList<News> getReviews() {
        return reviews;
    }

    public void setReviews(ArrayList<News> reviews) {
        this.reviews = reviews;
    }

    @Bindable
    public String getReview_total() {
        return "맛깔나는리뷰 (" + review_total + ")";
    }

    public void setReview_total(String review_total) {
        this.review_total = review_total;
    }

    @Bindable
    public String getReview_best() {
        return "맛있다! (" + review_best + ")";
    }

    public void setReview_best(String review_best) {
        this.review_best = review_best;
    }

    @Bindable
    public String getReview_good() {
        return "괜찮다 (" + review_good + ")";
    }

    public void setReview_good(String review_good) {
        this.review_good = review_good;
    }

    @Bindable
    public String getReview_bad() {
        return "별로 (" + review_bad + ")";
    }

    public void setReview_bad(String review_bad) {
        this.review_bad = review_bad;
    }

    @Bindable
    public boolean isHasTopList() {
        return !(toplist == null || toplist.size() == 0);
    }

    @Bindable
    public boolean isHasStory() {
        return !(stories == null || stories.size() == 0);
    }

    @Bindable
    public boolean isHasStore() {
        return !(store == null || store.size() == 0);
    }

    public boolean isHasReview() {
        return !(reviews == null || reviews.size() == 0);
    }

    public ArrayList<Story> getStories() {
        return stories;
    }

    public void setStories(ArrayList<Story> stories) {
        this.stories = stories;
    }

    public void attachMenu(ViewGroup viewGroup, ViewGroup menuImageLayout) {
        for (int i = 0; i < getMenus().size(); i++) {
            if (getMenus().get(i).getStoreMenuType() == StoreMenu.StoreMenuType.TEXT) {
                viewGroup.addView(getMenus().get(i).getView(viewGroup.getContext()));
            }
            else {
                menuImageLayout.addView(getMenus().get(i).getView(viewGroup.getContext()));
            }
        }
    }
}
