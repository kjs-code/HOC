package com.study.restaurant.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 "business_hour_id": "51",
 "store_id": "1",
 "day": "1",
 "start_hour": "10:00",
 "close_hour": "22:30"
 */
public class BusinessHour implements Parcelable {
    int business_hour_id;
    int store_id;
    int day;
    String start_hour;
    String close_hour;

    public BusinessHour() {
    }

    protected BusinessHour(Parcel in) {
        business_hour_id = in.readInt();
        store_id = in.readInt();
        day = in.readInt();
        start_hour = in.readString();
        close_hour = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(business_hour_id);
        dest.writeInt(store_id);
        dest.writeInt(day);
        dest.writeString(start_hour);
        dest.writeString(close_hour);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<BusinessHour> CREATOR = new Creator<BusinessHour>() {
        @Override
        public BusinessHour createFromParcel(Parcel in) {
            return new BusinessHour(in);
        }

        @Override
        public BusinessHour[] newArray(int size) {
            return new BusinessHour[size];
        }
    };

    public int getBusiness_hour_id() {
        return business_hour_id;
    }

    public void setBusiness_hour_id(int business_hour_id) {
        this.business_hour_id = business_hour_id;
    }

    public int getStore_id() {
        return store_id;
    }

    public void setStore_id(int store_id) {
        this.store_id = store_id;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public String getStart_hour() {
        return start_hour;
    }

    public void setStart_hour(String start_hour) {
        this.start_hour = start_hour;
    }

    public String getClose_hour() {
        return close_hour;
    }

    public void setClose_hour(String close_hour) {
        this.close_hour = close_hour;
    }
}
