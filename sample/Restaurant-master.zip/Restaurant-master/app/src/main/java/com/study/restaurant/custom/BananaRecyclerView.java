package com.study.restaurant.custom;

import android.content.Context;
import android.databinding.BindingAdapter;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;

public class BananaRecyclerView extends RecyclerView {

    boolean isLast = true;

    public void setLast(boolean last) {
        isLast = last;
    }

    public interface OnScrollUpListener {
        void onScrollUp();
    }

    public interface OnScrollDownListener {
        void onScrollDown();
    }

    public interface OnLastListener {
        void onLast();
    }

    private OnScrollUpListener onScrollUpListener;
    private OnScrollDownListener onScrollDownListener;
    private OnLastListener onLastListener;

    public void setOnLastListener(OnLastListener onLastListener) {
        this.onLastListener = onLastListener;
    }

    public void setOnScrollUpListener(OnScrollUpListener onScrollUpListener) {
        this.onScrollUpListener = onScrollUpListener;
    }

    public void setOnScrollDownListener(OnScrollDownListener onScrollDownListener) {
        this.onScrollDownListener = onScrollDownListener;
    }

    public BananaRecyclerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void onScrolled(int dx, int dy) {
        super.onScrolled(dx, dy);
        if (dy > 0) {
            if (onScrollDownListener != null)
                onScrollDownListener.onScrollDown();

        }
        else if (dy < 0) {
            if (onScrollUpListener != null)
                onScrollUpListener.onScrollUp();
        }
    }

    @Override
    public void onScrollStateChanged(int state) {
        super.onScrollStateChanged(state);
        if (!canScrollVertically(1) && !isLast) {
            if (onLastListener != null)
                onLastListener.onLast();
            isLast = true;
        }
        else {
        }
    }

    @BindingAdapter("app:onScrollUp")
    public static void onScrollUp(BananaRecyclerView bananaRecyclerView, BananaRecyclerView.OnScrollUpListener onScrollUpListener) {
        bananaRecyclerView.setOnScrollUpListener(onScrollUpListener);
    }

    @BindingAdapter("app:onScrollDown")
    public static void onScrollDown(BananaRecyclerView bananaRecyclerView, BananaRecyclerView.OnScrollDownListener onScrollDownListener) {
        bananaRecyclerView.setOnScrollDownListener(onScrollDownListener);
    }

    @BindingAdapter("app:onLast")
    public static void onLast(BananaRecyclerView bananaRecyclerView, BananaRecyclerView.OnLastListener onLastListener) {
        bananaRecyclerView.setOnLastListener(onLastListener);
    }
}
