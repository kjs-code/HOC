package com.study.restaurant.ui.news;

import android.arch.lifecycle.ViewModel;

public class NewsViewModel extends ViewModel {
}
