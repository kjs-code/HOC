package com.study.restaurant.model;

import java.util.ArrayList;

public class ImageBody {
    private String pic_id;
    private String review_id;
    private String number;
    private String user_id;
    private String store_id;
    private String pic_url;
    private String date;
    private String score;
    private String contents;
    private String like_count;
    private String comment_count;
    private String create_date;
    private String email;
    private String login_platform;
    private String profile_pic_url;
    private String name;
    private String follower;
    private String following;
    private String review;
    private String checkin;
    private String upload_pictures;
    private String level;
    private String password;
    private String uuid;

    public String getPic_id() {
        return pic_id;
    }

    public void setPic_id(String pic_id) {
        this.pic_id = pic_id;
    }

    public String getReview_id() {
        return review_id;
    }

    public void setReview_id(String review_id) {
        this.review_id = review_id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getPic_url() {
        return pic_url;
    }

    public void setPic_url(String pic_url) {
        this.pic_url = pic_url;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public String getLike_count() {
        return like_count;
    }

    public void setLike_count(String like_count) {
        this.like_count = like_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public String getCreate_date() {
        return create_date;
    }

    public void setCreate_date(String create_date) {
        this.create_date = create_date;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLogin_platform() {
        return login_platform;
    }

    public void setLogin_platform(String login_platform) {
        this.login_platform = login_platform;
    }

    public String getProfile_pic_url() {
        return profile_pic_url;
    }

    public void setProfile_pic_url(String profile_pic_url) {
        this.profile_pic_url = profile_pic_url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFollower() {
        return follower;
    }

    public void setFollower(String follower) {
        this.follower = follower;
    }

    public String getFollowing() {
        return following;
    }

    public void setFollowing(String following) {
        this.following = following;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getCheckin() {
        return checkin;
    }

    public void setCheckin(String checkin) {
        this.checkin = checkin;
    }

    public String getUpload_pictures() {
        return upload_pictures;
    }

    public void setUpload_pictures(String upload_pictures) {
        this.upload_pictures = upload_pictures;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public News toNews() {
        News news = new News();
        news.setUser_id(getUser_id());
        StorePicture storePicture = new StorePicture();
        storePicture.setStore_id(getStore_id());
        storePicture.setUser_id(getUser_id());
        storePicture.setPic_url(getPic_url());
        storePicture.setNumber(getNumber());
        storePicture.setDate(getDate());
        ArrayList<StorePicture> storePictures = new ArrayList<>();
        storePictures.add(storePicture);
        news.setStorePictures(storePictures);
        news.setContents(getContents());
        news.setProfile_pic_url(getProfile_pic_url());
        news.setName(getName());


        return news;
    }
}
