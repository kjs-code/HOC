package com.study.restaurant.model;

public class Banner {
    public Object toParam() {
        return null;
    }
}
