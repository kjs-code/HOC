# 망고 플레이트 화면 분석

[TOC]



### 스플레시

<img src = ./mango_screen/splash.jpg width=300>



### 메인

<img src = ./mango_screen/main.jpg width=300>





### 로그인

<img src = ./mango_screen/login.jpg width=300>

## 소식

### 소식-홀릭

<img src = ./mango_screen/news_holic.jpg width=300>

### 소식-전체

<img src = ./mango_screen/news_all.jpg width=300>

### 소식 팔로잉

<img src = ./mango_screen/news_following.jpg width=300>

### 프로필

<img src = ./mango_screen/profile.jpg width=300>

## 맛집 상세

### 맛집 상세

<img src = ./mango_screen/restaurant_detail.jpg width=300>

### 맛집 상세1

<img src = ./mango_screen/restaurant_detail1.jpg width=300>



### 맛집 상세2

<img src = ./mango_screen/restaurant_detail2.jpg width=300>

## 망고픽

### 망고픽-스토리

<img src = ./mango_screen/story.jpg width=300>

### 망고픽-탑리스트

<img src = ./mango_screen/top_list.jpg width=300>