# OKHTTPUploadImage

Uploading Image using OKHTTP.

You can check my answers on StackOverflow for [Single Image Upload using OkHttp](http://stackoverflow.com/a/34127008/1318946) and [Multiple Image Upload using OkHttp](http://stackoverflow.com/a/34411666/1318946)

Thank you. Keep Sharing.